import java.io.*;

public class Main {

    public static void main(String[] args) {
        try {
            FileReader leggiA = new FileReader("A&B/A.txt");
            FileReader leggiB = new FileReader("A&B/B.txt");
            FileWriter ScriviOut = new FileWriter("output.txt");
            BufferedReader leggiPiuA = new BufferedReader(leggiA);
            BufferedReader leggiPiuB = new BufferedReader(leggiB);
            BufferedWriter scriviPiuOut = new BufferedWriter(ScriviOut);
            while (leggiPiuA.ready() && leggiPiuB.ready()) {
                scriviPiuOut.write(leggiPiuA.readLine());
                scriviPiuOut.newLine();
                scriviPiuOut.write(leggiPiuB.readLine());
                scriviPiuOut.newLine();
                scriviPiuOut.flush();
            }
            while (leggiPiuA.ready()) {
                scriviPiuOut.write(leggiPiuA.readLine());
                scriviPiuOut.newLine();
                scriviPiuOut.flush();
            }


            while (leggiPiuB.ready()) {
                scriviPiuOut.write(leggiPiuB.readLine());
                scriviPiuOut.newLine();
                scriviPiuOut.flush();
            }
        } catch (Exception e) {
            System.out.println("file non trovato");
        }
    }
}
