import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        File dir = new File("A&B");
        String string1 = "", string2 = "";
        Scanner sc = new Scanner(System.in);
        System.out.println("Scegli file:");
        System.out.print(Arrays.toString(dir.list()) + "\n>");
        string1 = sc.nextLine();
        sc = new Scanner(System.in);
        System.out.print(">");
        string2 = sc.nextLine();
        scrivifile(string1, string2);
    }

    private static void scrivifile(String string1, String string2) {
        try {
            FileReader leggi1 = new FileReader("A&B/" + string1);
            FileReader leggi2 = new FileReader("A&B/" + string2);
            FileWriter ScriviOut = new FileWriter("output.txt");
            BufferedReader leggiPiu1 = new BufferedReader(leggi1);
            BufferedReader leggiPiu2 = new BufferedReader(leggi2);
            BufferedWriter scriviPiuOut = new BufferedWriter(ScriviOut);
            while (leggiPiu1.ready() && leggiPiu2.ready()) {
                scriviPiuOut.write(leggiPiu1.readLine());
                scriviPiuOut.newLine();
                scriviPiuOut.write(leggiPiu2.readLine());
                scriviPiuOut.newLine();
                scriviPiuOut.flush();
            }
            while (leggiPiu1.ready()) {
                scriviPiuOut.write(leggiPiu1.readLine());
                scriviPiuOut.newLine();
                scriviPiuOut.flush();
            }
            while (leggiPiu2.ready()) {
                scriviPiuOut.write(leggiPiu2.readLine());
                scriviPiuOut.newLine();
                scriviPiuOut.flush();
            }
        } catch (Exception e) {
            System.out.println("file non trovato");
        }
    }
}
